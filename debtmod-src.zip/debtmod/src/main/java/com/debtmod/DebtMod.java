package com.debtmod;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.EntitySleepEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.WorldSavePath;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;

import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

public class DebtMod implements ModInitializer {
    public static final String MOD_ID = "debtmod";

    // ===================== الإعدادات (غيّر الأرقام هنا) =====================
    static final long START_BALANCE = 500;
    static final long SLEEP_COST = 50;        // كل مرة تنام
    static final long DEATH_COST = 100;       // كل مرة تموت
    static final long ELYTRA_COST_PER_SEC = 5;// كل ثانية طيران بالالترا
    static final int COIN_VALUE = 10;         // قيمة العملة الواحدة
    static final int GRACE_TICKS = 6000;      // مهلة سداد الدين (5 دقائق)
    // السجن
    static final int PX = 20000, PY = 100, PZ = 20000;
    static final int QUOTA_COBBLE = 64, QUOTA_COAL = 10, QUOTA_IRON = 6;
    // ======================================================================

    public static Item COIN;
    static MinecraftServer SERVER;
    static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    static Map<String, PlayerData> DATA = new HashMap<>();
    static boolean prisonBuilt = false;

    public static class PlayerData {
        public long balance = START_BALANCE;
        public long debtSince = -1;
        public boolean jailed = false;
        public double rx, ry, rz;
        public String rdim = "minecraft:overworld";
    }

    static class Save { Map<String, PlayerData> players = new HashMap<>(); boolean prisonBuilt; }

    static final Map<Item, Integer> PRICES = new LinkedHashMap<>();
    static {
        PRICES.put(Items.COBBLESTONE, 1); PRICES.put(Items.DIRT, 1);
        PRICES.put(Items.OAK_LOG, 3); PRICES.put(Items.WHEAT, 2);
        PRICES.put(Items.COAL, 3); PRICES.put(Items.RAW_IRON, 5);
        PRICES.put(Items.IRON_INGOT, 8); PRICES.put(Items.RAW_GOLD, 8);
        PRICES.put(Items.GOLD_INGOT, 15); PRICES.put(Items.REDSTONE, 3);
        PRICES.put(Items.LAPIS_LAZULI, 4); PRICES.put(Items.EMERALD, 40);
        PRICES.put(Items.DIAMOND, 100); PRICES.put(Items.NETHERITE_INGOT, 600);
        PRICES.put(Items.BREAD, 4); PRICES.put(Items.BEEF, 3);
        PRICES.put(Items.COOKED_BEEF, 6); PRICES.put(Items.ROTTEN_FLESH, 1);
        PRICES.put(Items.BONE, 2); PRICES.put(Items.GUNPOWDER, 4);
    }

    @Override
    public void onInitialize() {
        RegistryKey<Item> key = RegistryKey.of(RegistryKeys.ITEM, Identifier.of(MOD_ID, "coin"));
        COIN = Registry.register(Registries.ITEM, key, new CoinItem(new Item.Settings().registryKey(key)));

        ServerLifecycleEvents.SERVER_STARTED.register(s -> { SERVER = s; load(s); });
        ServerLifecycleEvents.SERVER_STOPPING.register(s -> save(s));

        // نوم = خصم
        EntitySleepEvents.STOP_SLEEPING.register((entity, pos) -> {
            if (entity instanceof ServerPlayerEntity p) charge(p, SLEEP_COST, "نوم");
        });
        // موت = خصم
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, src) -> {
            if (entity instanceof ServerPlayerEntity p) charge(p, DEATH_COST, "موت");
        });

        ServerTickEvents.END_SERVER_TICK.register(this::tick);
        CommandRegistrationCallback.EVENT.register((d, reg, env) -> registerCommands(d));
    }

    // ---------------- المال ----------------
    static PlayerData data(ServerPlayerEntity p) {
        return DATA.computeIfAbsent(p.getUuid().toString(), k -> new PlayerData());
    }

    static void charge(ServerPlayerEntity p, long amt, String why) {
        PlayerData d = data(p);
        d.balance -= amt;
        p.sendMessage(Text.literal("-" + amt + "$ (" + why + ")  |  الرصيد: " + d.balance), true);
    }

    static void add(ServerPlayerEntity p, long amt) {
        PlayerData d = data(p);
        d.balance += amt;
        p.sendMessage(Text.literal("+" + amt + "$  |  الرصيد: " + d.balance), true);
    }

    // ---------------- التيك ----------------
    void tick(MinecraftServer server) {
        int t = server.getTicks();
        if (t % 20 != 0) return;
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            PlayerData d = data(p);

            if (p.isGliding()) charge(p, ELYTRA_COST_PER_SEC, "طيران");

            if (d.jailed) { keepInPrison(p); continue; }

            if (d.balance < 0) {
                if (d.debtSince < 0) {
                    d.debtSince = t;
                    p.sendMessage(Text.literal("⚠ عليك دين " + (-d.balance) + "$! سدّده خلال 5 دقايق وإلا السجن."), false);
                } else {
                    int left = GRACE_TICKS - (t - (int) d.debtSince);
                    if (left <= 0) { jail(p); }
                    else if (left % 1200 < 20) {
                        p.sendMessage(Text.literal("⚠ باقي " + (left / 20) + " ثانية على السجن. دينك: " + (-d.balance) + "$"), false);
                    }
                }
            } else {
                d.debtSince = -1;
            }
        }
        if (t % 1200 == 0) save(server);
    }

    // ---------------- السجن ----------------
    static void buildPrison(ServerWorld w) {
        if (prisonBuilt) return;
        Random r = w.getRandom();
        for (int dx = -7; dx <= 7; dx++)
            for (int dz = -7; dz <= 7; dz++)
                for (int y = PY - 1; y <= PY + 8; y++) {
                    boolean shell = Math.abs(dx) == 7 || Math.abs(dz) == 7 || y == PY - 1 || y == PY + 8;
                    Block b;
                    if (shell) b = Blocks.BEDROCK;
                    else {
                        float f = r.nextFloat();
                        b = f < 0.05f ? Blocks.COAL_ORE : f < 0.09f ? Blocks.IRON_ORE : Blocks.STONE;
                    }
                    w.setBlockState(new BlockPos(PX + dx, y, PZ + dz), b.getDefaultState(), Block.NOTIFY_LISTENERS);
                }
        for (int dx = -1; dx <= 1; dx++)
            for (int dz = -1; dz <= 1; dz++)
                for (int y = PY; y <= PY + 2; y++)
                    w.setBlockState(new BlockPos(PX + dx, y, PZ + dz), Blocks.AIR.getDefaultState(), Block.NOTIFY_LISTENERS);
        w.setBlockState(new BlockPos(PX + 1, PY, PZ + 1), Blocks.TORCH.getDefaultState(), Block.NOTIFY_LISTENERS);
        w.setBlockState(new BlockPos(PX - 1, PY, PZ - 1), Blocks.TORCH.getDefaultState(), Block.NOTIFY_LISTENERS);
        prisonBuilt = true;
    }

    static void tpTo(ServerPlayerEntity p, ServerWorld w, double x, double y, double z) {
        p.teleport(w, x, y, z, Set.of(), p.getYaw(), p.getPitch(), false);
    }

    static void jail(ServerPlayerEntity p) {
        PlayerData d = data(p);
        ServerWorld over = SERVER.getOverworld();
        buildPrison(over);
        d.jailed = true;
        d.rx = p.getX(); d.ry = p.getY(); d.rz = p.getZ();
        d.rdim = p.getEntityWorld().getRegistryKey().getValue().toString();
        tpTo(p, over, PX + 0.5, PY, PZ + 0.5);
        p.getInventory().offerOrDrop(new ItemStack(Items.STONE_PICKAXE));
        p.getInventory().offerOrDrop(new ItemStack(Items.STONE_PICKAXE));
        p.getInventory().offerOrDrop(new ItemStack(Items.BREAD, 16));
        p.sendMessage(Text.literal("🔒 انسجنت بسبب الدين! اجمع: " + QUOTA_COBBLE + " كوبلستون، "
                + QUOTA_COAL + " فحم، " + QUOTA_IRON + " حديد خام ثم اكتب /escape"), false);
    }

    static void keepInPrison(ServerPlayerEntity p) {
        boolean inside = p.getEntityWorld().getRegistryKey() == World.OVERWORLD
                && Math.abs(p.getX() - PX) < 7 && Math.abs(p.getZ() - PZ) < 7
                && p.getY() > PY - 1 && p.getY() < PY + 8;
        if (!inside) tpTo(p, SERVER.getOverworld(), PX + 0.5, PY, PZ + 0.5);
    }

    static int count(ServerPlayerEntity p, Item item) {
        int n = 0;
        for (int i = 0; i < p.getInventory().size(); i++) {
            ItemStack s = p.getInventory().getStack(i);
            if (s.isOf(item)) n += s.getCount();
        }
        return n;
    }

    static void take(ServerPlayerEntity p, Item item, int amount) {
        for (int i = 0; i < p.getInventory().size() && amount > 0; i++) {
            ItemStack s = p.getInventory().getStack(i);
            if (s.isOf(item)) { int k = Math.min(amount, s.getCount()); s.decrement(k); amount -= k; }
        }
    }

    // ---------------- الأوامر ----------------
    void registerCommands(com.mojang.brigadier.CommandDispatcher<net.minecraft.server.command.ServerCommandSource> d) {
        d.register(CommandManager.literal("money").executes(c -> {
            ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
            PlayerData pd = data(p);
            String s = "💰 رصيدك: " + pd.balance + "$" + (pd.balance < 0 ? "  (دين!)" : "");
            c.getSource().sendFeedback(() -> Text.literal(s), false);
            return 1;
        }));

        d.register(CommandManager.literal("sell").executes(c -> {
            ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
            ItemStack s = p.getMainHandStack();
            Integer price = PRICES.get(s.getItem());
            if (price == null || s.isEmpty()) {
                c.getSource().sendFeedback(() -> Text.literal("هذا الشي ما يتباع"), false);
                return 0;
            }
            long total = (long) price * s.getCount();
            s.setCount(0);
            add(p, total);
            return 1;
        }));

        d.register(CommandManager.literal("sellall").executes(c -> {
            ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
            long total = 0;
            for (int i = 0; i < p.getInventory().size(); i++) {
                ItemStack s = p.getInventory().getStack(i);
                Integer price = PRICES.get(s.getItem());
                if (price != null && !s.isEmpty()) { total += (long) price * s.getCount(); s.setCount(0); }
            }
            add(p, total);
            return 1;
        }));

        d.register(CommandManager.literal("prices").executes(c -> {
            StringBuilder sb = new StringBuilder("📋 الأسعار:\n");
            PRICES.forEach((k, v) -> sb.append(k.getName().getString()).append(": ").append(v).append("$\n"));
            c.getSource().sendFeedback(() -> Text.literal(sb.toString()), false);
            return 1;
        }));

        d.register(CommandManager.literal("withdraw")
                .then(CommandManager.argument("coins", IntegerArgumentType.integer(1, 2304)).executes(c -> {
                    ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
                    PlayerData pd = data(p);
                    int n = IntegerArgumentType.getInteger(c, "coins");
                    long cost = (long) n * COIN_VALUE;
                    if (pd.balance < cost) {
                        c.getSource().sendFeedback(() -> Text.literal("رصيدك ما يكفي"), false);
                        return 0;
                    }
                    pd.balance -= cost;
                    int left = n;
                    while (left > 0) {
                        int k = Math.min(left, 64);
                        p.getInventory().offerOrDrop(new ItemStack(COIN, k));
                        left -= k;
                    }
                    c.getSource().sendFeedback(() -> Text.literal("سحبت " + n + " كوينز (كل وحدة " + COIN_VALUE + "$). الرصيد: " + pd.balance), false);
                    return 1;
                })));

        d.register(CommandManager.literal("jailstatus").executes(c -> {
            ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
            if (!data(p).jailed) {
                c.getSource().sendFeedback(() -> Text.literal("انت مو مسجون"), false);
                return 0;
            }
            String s = "المطلوب للخروج:\nكوبلستون " + count(p, Items.COBBLESTONE) + "/" + QUOTA_COBBLE
                    + "\nفحم " + count(p, Items.COAL) + "/" + QUOTA_COAL
                    + "\nحديد خام " + count(p, Items.RAW_IRON) + "/" + QUOTA_IRON;
            c.getSource().sendFeedback(() -> Text.literal(s), false);
            return 1;
        }));

        d.register(CommandManager.literal("escape").executes(c -> {
            ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
            PlayerData pd = data(p);
            if (!pd.jailed) {
                c.getSource().sendFeedback(() -> Text.literal("انت مو مسجون"), false);
                return 0;
            }
            if (count(p, Items.COBBLESTONE) < QUOTA_COBBLE || count(p, Items.COAL) < QUOTA_COAL
                    || count(p, Items.RAW_IRON) < QUOTA_IRON) {
                c.getSource().sendFeedback(() -> Text.literal("ما كملت الموارد. اكتب /jailstatus"), false);
                return 0;
            }
            take(p, Items.COBBLESTONE, QUOTA_COBBLE);
            take(p, Items.COAL, QUOTA_COAL);
            take(p, Items.RAW_IRON, QUOTA_IRON);
            pd.jailed = false;
            pd.debtSince = -1;
            pd.balance = 0; // الدين انمسح
            ServerWorld w = SERVER.getWorld(RegistryKey.of(RegistryKeys.WORLD, Identifier.of(pd.rdim)));
            if (w == null) w = SERVER.getOverworld();
            tpTo(p, w, pd.rx, pd.ry, pd.rz);
            p.sendMessage(Text.literal("🔓 طلعت من السجن والدين انمسح. رصيدك الحين 0$"), false);
            return 1;
        }));
    }

    // ---------------- الحفظ ----------------
    static Path file(MinecraftServer s) { return s.getSavePath(WorldSavePath.ROOT).resolve("debtmod.json"); }

    static void load(MinecraftServer s) {
        try {
            Path f = file(s);
            if (Files.exists(f)) {
                try (Reader r = Files.newBufferedReader(f, StandardCharsets.UTF_8)) {
                    Save sv = GSON.fromJson(r, new TypeToken<Save>() {}.getType());
                    if (sv != null) { DATA = sv.players; prisonBuilt = sv.prisonBuilt; }
                }
            }
        } catch (Exception e) { e.printStackTrace(); }
    }

    static void save(MinecraftServer s) {
        try (Writer w = Files.newBufferedWriter(file(s), StandardCharsets.UTF_8)) {
            Save sv = new Save(); sv.players = DATA; sv.prisonBuilt = prisonBuilt;
            GSON.toJson(sv, w);
        } catch (Exception e) { e.printStackTrace(); }
    }
}
